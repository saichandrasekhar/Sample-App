package com.example.cdevarakonda.sample2;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void btnLogin(View view) {
        try {

            /* Data ( username and password ) should be validated from the server. */

            EditText username = (EditText) findViewById(R.id.username);
            EditText password = (EditText) findViewById(R.id.password);
            /*LoginDetail LD = new LoginDetail();
            for (Map.Entry<String, String> entry : LD.list.entrySet()) {
                if (entry.getKey().equals(username.toString()) && entry.getValue().equals(password.toString())) {
                }
            }*/
            Intent searchIntent = new Intent(this, searchActivity.class);
            startActivity(searchIntent);

            Toast.makeText(getApplicationContext(), "You have successfully logged in!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {

            Toast.makeText(getApplicationContext(), "Unknown Exception!", Toast.LENGTH_LONG).show();
        }
    }
}