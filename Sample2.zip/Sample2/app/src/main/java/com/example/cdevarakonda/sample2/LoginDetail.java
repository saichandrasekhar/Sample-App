package com.example.cdevarakonda.sample2;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by cdevarakonda on 3/16/2016.
 */
public class LoginDetail {
    Map<String,String> list=new HashMap<>();
    {
        list.put("batman","darkknight");
        list.put("superman","returns");
    }

}
