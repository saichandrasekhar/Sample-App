package com.example.cdevarakonda.sample2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class showList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list);


        /* This activity should show a list of items along with a checkbox for each item. when the user clicks
         submit button, we should take all the checked items data and send it to the server and should get
         updated in the database.
          */


        String s[] = new String[]{"one", "two", "three"}; // This should be declared in a class containing two variables, one is checkbox and other is textview

        ListView list = (ListView) findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.activity_show_list, R.id.tvList, s);
        list.setAdapter(adapter);
    }
}
